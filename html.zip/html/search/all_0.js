var searchData=
[
  ['adjustleaderboard_0',['adjustLeaderBoard',['../main_8c.html#a41dbad2d0320c0fc0f8b5d039612a086',1,'main.c']]],
  ['alphabet_1',['alphabet',['../main_8c.html#a868cd98787af7fa52d07bb7562418c57',1,'main.c']]]
];
