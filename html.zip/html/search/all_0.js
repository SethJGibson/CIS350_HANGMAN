var searchData=
[
  ['alphabet_0',['alphabet',['../main_8c.html#a868cd98787af7fa52d07bb7562418c57',1,'main.c']]]
];
