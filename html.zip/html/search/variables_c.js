var searchData=
[
  ['wincounter_0',['winCounter',['../main_8c.html#a31b1e14e80f99e12a974e80ca760d26e',1,'main.c']]],
  ['word_1',['word',['../main_8c.html#af034065dfe33f7ef74362e100b14b260',1,'main.c']]],
  ['workingalpha_2',['workingAlpha',['../main_8c.html#a5e6e0a31e3e8cd5fa03ae25856d38012',1,'main.c']]]
];
