var indexSectionsWithContent =
{
  0: "abcghilmprswx",
  1: "mw",
  2: "cghlmprs",
  3: "abcilpwx"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables"
};

