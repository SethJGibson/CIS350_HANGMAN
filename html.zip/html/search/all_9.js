var searchData=
[
  ['removechar_0',['removeChar',['../main_8c.html#a1ed3469ee414bde0ea82c2ba38e73a50',1,'main.c']]],
  ['reset_1',['reset',['../main_8c.html#ad20897c5c8bd47f5d4005989bead0e55',1,'main.c']]]
];
