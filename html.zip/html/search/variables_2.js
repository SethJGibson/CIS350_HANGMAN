var searchData=
[
  ['correctword_0',['correctWord',['../main_8c.html#a6596fbbbd2e64fcc6c461f041c59377d',1,'main.c']]]
];
