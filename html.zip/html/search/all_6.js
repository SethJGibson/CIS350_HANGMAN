var searchData=
[
  ['gameinprogressbutton_0',['gameInProgressButton',['../main_8c.html#a778d1b322fc689bd363f573f71f9ca6f',1,'main.c']]],
  ['gameinprogressrotate_1',['gameInProgressRotate',['../main_8c.html#a38ae56c520118c4b34dc4a92e03aa41e',1,'main.c']]],
  ['gamelose_2',['gameLose',['../main_8c.html#abf9793384c295bc2bb96c00bc3ae9067',1,'main.c']]],
  ['gamewin_3',['gameWin',['../main_8c.html#a47c38e3fe05dad917208c8daa661adf3',1,'main.c']]]
];
