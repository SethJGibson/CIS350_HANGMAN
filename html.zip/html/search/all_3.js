var searchData=
[
  ['gamelose_0',['gameLose',['../main_8c.html#abf9793384c295bc2bb96c00bc3ae9067',1,'main.c']]],
  ['gamewin_1',['gameWin',['../main_8c.html#a47c38e3fe05dad917208c8daa661adf3',1,'main.c']]]
];
