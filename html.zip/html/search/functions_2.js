var searchData=
[
  ['difficultybutton_0',['difficultyButton',['../main_8c.html#a699f8241861224a8d329473a529575bd',1,'main.c']]],
  ['difficultyrotate_1',['difficultyRotate',['../main_8c.html#a724c4a6102edda53057fc7f8cfca2f1a',1,'main.c']]],
  ['display_5feeprom_2',['Display_EEPROM',['../main_8c.html#a62149da87f0bf7e834368bd484c75556',1,'main.c']]]
];
