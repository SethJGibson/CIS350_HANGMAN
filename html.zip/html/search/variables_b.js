var searchData=
[
  ['score_0',['score',['../main_8c.html#aef160b7437d94056f1dc59646cd5b87d',1,'main.c']]],
  ['scorestring_1',['scoreString',['../main_8c.html#aebd88531e55e178607da7f328f7d8189',1,'main.c']]],
  ['state_2',['state',['../main_8c.html#a89f234133d3efe315836311cbf21c64b',1,'main.c']]]
];
