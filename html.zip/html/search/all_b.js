var searchData=
[
  ['namecharselect_0',['nameCharSelect',['../main_8c.html#a352e25bbc7466f1137caa409a868a100',1,'main.c']]],
  ['nameselect_1',['nameSelect',['../main_8c.html#a51b9dd855aa4f38db43d8a291a083a05',1,'main.c']]]
];
