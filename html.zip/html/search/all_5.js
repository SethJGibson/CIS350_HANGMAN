var searchData=
[
  ['firsttime_0',['firstTime',['../main_8c.html#ad4066c6e83290040e1f715f0617d53f7',1,'main.c']]]
];
