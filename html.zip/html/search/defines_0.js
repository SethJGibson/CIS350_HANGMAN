var searchData=
[
  ['diff_5flength_0',['DIFF_LENGTH',['../main_8c.html#ace8e5b26d15c57d1a6bc78258e55dec6',1,'main.c']]]
];
