var searchData=
[
  ['eeprom_5fslave_5faddr_5fread_0',['EEPROM_SLAVE_ADDR_READ',['../main_8c.html#afe3f96686ab0e1d4073f1219a671220f',1,'main.c']]],
  ['eeprom_5fslave_5faddr_5fwrite_1',['EEPROM_SLAVE_ADDR_WRITE',['../main_8c.html#aefe8a57c19809316f2fbf98127bbd583',1,'main.c']]]
];
