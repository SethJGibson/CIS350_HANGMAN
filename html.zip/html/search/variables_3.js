var searchData=
[
  ['difficulty_0',['difficulty',['../main_8c.html#a52d317f3e6666f41409780f729f6ff68',1,'main.c']]],
  ['diffstate_1',['diffState',['../main_8c.html#ac557be939c528f0622b6ee0b58b4b412',1,'main.c']]]
];
