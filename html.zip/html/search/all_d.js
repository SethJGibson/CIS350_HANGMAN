var searchData=
[
  ['readfromleaderboard_0',['readFromLeaderBoard',['../main_8c.html#aea9c2248842fdde26286392661b94fbb',1,'main.c']]],
  ['removechar_1',['removeChar',['../main_8c.html#a1ed3469ee414bde0ea82c2ba38e73a50',1,'main.c']]],
  ['reset_2',['reset',['../main_8c.html#ad20897c5c8bd47f5d4005989bead0e55',1,'main.c']]]
];
