var searchData=
[
  ['x_0',['x',['../main_8c.html#a2b8744c8f0d2d8d22f1dd70c680efb44',1,'main.c']]]
];
